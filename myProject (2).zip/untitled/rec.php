<?php
// Vérifie si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupère les données du formulaire
    $name = $_POST["name"];
    $email = $_POST["email"];
    $recipe = $_POST["recipe"];

    // Connexion à la base de données
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifie la connexion à la base de données
    if ($conn->connect_error) {
        die("La connexion à la base de données a échoué : " . $conn->connect_error);
    }

    // Prépare et exécute la requête SQL pour insérer les données dans la base de données
    $stmt = $conn->prepare("INSERT INTO formulaire (name, email, recipe) VALUES (?, ?, ?)");

    // Vérifie si la préparation de la requête a réussi
    if ($stmt === false) {
        die("Erreur de préparation de la requête : " . $conn->error);
    }

    // Lie les paramètres à la requête
    $stmt->bind_param("sss", $name, $email, $recipe);

    // Exécute la requête
    if ($stmt->execute() === false) {
        die("Erreur lors de l'exécution de la requête : " . $stmt->error);
    }

    // Ferme la connexion à la base de données
    $stmt->close();
    $conn->close();

    // Affiche un message de réussite
    echo "Enregistrement des données réussi.";
}
?>
